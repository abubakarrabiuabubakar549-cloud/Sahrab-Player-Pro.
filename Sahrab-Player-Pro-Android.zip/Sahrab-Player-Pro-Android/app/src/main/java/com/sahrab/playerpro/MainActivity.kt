package com.sahrab.playerpro

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var playerView: PlayerView
    private lateinit var listArea: LinearLayout
    private lateinit var statusText: TextView
    private var player: ExoPlayer? = null
    private var showingVideos = true
    private var currentUri: Uri? = null
    private val prefs by lazy { getSharedPreferences("sahrab_player", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 13, 22)
        window.navigationBarColor = Color.rgb(9, 13, 22)
        buildUi()
        if (hasMediaPermission()) loadLibrary() else requestMediaPermission()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(9, 13, 22))
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        val brand = TextView(this).apply {
            text = "SAHRAB PLAYER PRO"
            textSize = 22f
            setTextColor(Color.rgb(32, 214, 181))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, dp(42)))
        val tagline = TextView(this).apply {
            text = "YOUR MEDIA. YOUR WAY.  •  OFFLINE PLAYER"
            textSize = 10f
            setTextColor(Color.LTGRAY)
        }
        root.addView(tagline, LinearLayout.LayoutParams(-1, dp(24)))

        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(Color.BLACK)
        }
        root.addView(playerView, LinearLayout.LayoutParams(-1, dp(220)))

        statusText = TextView(this).apply {
            text = "Choose a video or song below"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(0, dp(10), 0, dp(10))
        }
        root.addView(statusText, LinearLayout.LayoutParams(-1, -2))

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val videosButton = makeButton("VIDEOS") { showingVideos = true; loadLibrary() }
        val musicButton = makeButton("MUSIC") { showingVideos = false; loadLibrary() }
        tabs.addView(videosButton, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        tabs.addView(musicButton, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(6) })
        root.addView(tabs, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this).apply { isFillViewport = true }
        listArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(12)) }
        scroll.addView(listArea)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(24, 43, 55))
        setOnClickListener { action() }
    }

    private fun hasMediaPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
        } else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestMediaPermission() {
        val permissions = if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        requestPermissions(permissions, 40)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 40) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) loadLibrary()
            else Toast.makeText(this, "Allow media access to show files on your phone.", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadLibrary() {
        if (!::listArea.isInitialized) return
        listArea.removeAllViews()
        val collection = if (showingVideos) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val titleColumn = if (showingVideos) MediaStore.Video.Media.TITLE else MediaStore.Audio.Media.TITLE
        val idColumn = if (showingVideos) MediaStore.Video.Media._ID else MediaStore.Audio.Media._ID
        val durationColumn = if (showingVideos) MediaStore.Video.Media.DURATION else MediaStore.Audio.Media.DURATION
        val projection = arrayOf(idColumn, titleColumn, durationColumn)
        var count = 0
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(collection, projection, null, null, "$titleColumn COLLATE NOCASE ASC")
            cursor?.use { c ->
                val idIndex = c.getColumnIndexOrThrow(idColumn)
                val titleIndex = c.getColumnIndexOrThrow(titleColumn)
                val durationIndex = c.getColumnIndexOrThrow(durationColumn)
                while (c.moveToNext()) {
                    val id = c.getLong(idIndex)
                    val title = c.getString(titleIndex) ?: if (showingVideos) "Video" else "Audio"
                    val duration = c.getLong(durationIndex)
                    val uri = ContentUris.withAppendedId(collection, id)
                    addMediaRow(title, duration, uri)
                    count++
                }
            }
        } catch (e: Exception) {
            statusText.text = "Could not read media. Please allow media access in Settings."
        } finally { cursor?.close() }
        if (count == 0) {
            val empty = TextView(this).apply {
                text = if (showingVideos) "No videos found on this device." else "No music found on this device."
                textSize = 15f
                setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(30), dp(12), dp(30))
            }
            listArea.addView(empty)
        }
        statusText.text = "$count ${if (showingVideos) "videos" else "audio files"} found • Works offline"
    }

    private fun addMediaRow(title: String, durationMs: Long, uri: Uri) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(Color.rgb(17, 24, 37))
            isClickable = true
            isFocusable = true
            setOnClickListener { playMedia(title, uri) }
        }
        val titleView = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(Color.WHITE)
            maxLines = 2
        }
        val detail = TextView(this).apply {
            text = "${formatDuration(durationMs)}  •  Tap to play"
            textSize = 11f
            setTextColor(Color.rgb(32, 214, 181))
            setPadding(0, dp(4), 0, 0)
        }
        row.addView(titleView)
        row.addView(detail)
        listArea.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
    }

    private fun playMedia(title: String, uri: Uri) {
        try {
            if (player == null) {
                player = ExoPlayer.Builder(this).build().also { playerView.player = it }
            }
            currentUri = uri
            player?.setMediaItem(MediaItem.fromUri(uri))
            player?.prepare()
            player?.playWhenReady = true
            statusText.text = "Now playing: $title"
            Toast.makeText(this, "Playing offline", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to play this file on this device.", Toast.LENGTH_LONG).show()
        }
    }

    private fun formatDuration(ms: Long): String {
        val total = ms / 1000
        return String.format("%02d:%02d", total / 60, total % 60)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onPause() {
        super.onPause()
        val p = player ?: return
        prefs.edit().putLong("last_position", p.currentPosition).putString("last_uri", currentUri?.toString()).apply()
    }

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }
}
